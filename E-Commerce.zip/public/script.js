// Sample products
const products = [
    { id: 1, name: "Laptop", price: 500, image: "a.png" },
    { id: 2, name: "Headphones", price: 50, image: "b.avif" },
    { id: 3, name: "Smartphone", price: 300, image: "c.png" }
];

let cart = [];

// Function to display products
function loadProducts() {
    const productContainer = document.getElementById("products");
    productContainer.innerHTML = "";

    products.forEach(product => {
        const productHTML = `
            <div class="product">
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>$${product.price}</p>
                <button onclick="addToCart(${product.id})">Add to Cart</button>
            </div>
        `;
        productContainer.innerHTML += productHTML;
    });
}

// Function to add items to cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    cart.push(product);
    updateCart();
}

// Function to update cart display
function updateCart() {
    const cartCount = document.getElementById("cart-count");
    const cartItems = document.getElementById("cart-items");
    const cartTotal = document.getElementById("cart-total");

    cartCount.innerText = cart.length;
    cartItems.innerHTML = "";

    let total = 0;
    cart.forEach(item => {
        total += item.price;
        cartItems.innerHTML += `<li>${item.name} - $${item.price}</li>`;
    });

    cartTotal.innerText = total;
}

// Function for checkout
function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }
    alert("Thank you for your purchase!");
    cart = [];
    updateCart();
}

// Load products when page loads
window.onload = loadProducts;
