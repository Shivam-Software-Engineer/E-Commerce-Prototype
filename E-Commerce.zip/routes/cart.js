const express = require("express");
const router = express.Router();
const Cart = require("../models/Cart");

// Get cart items
router.get("/", async (req, res) => {
  try {
    const cart = await Cart.findOne().populate("products");
    res.json(cart);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add item to cart
router.post("/add", async (req, res) => {
  const { productId } = req.body;
  try {
    let cart = await Cart.findOne();
    if (!cart) {
      cart = new Cart({ products: [] });
    }
    cart.products.push(productId);
    await cart.save();
    res.json(cart);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
